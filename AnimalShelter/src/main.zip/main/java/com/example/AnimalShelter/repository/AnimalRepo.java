package com.example.AnimalShelter.repository;

import com.example.AnimalShelter.entity.AnimalEntity;
import org.springframework.data.repository.CrudRepository;

public interface AnimalRepo extends CrudRepository<AnimalEntity, Long> {
}
