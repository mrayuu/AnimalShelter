package com.example.AnimalShelter.repository;

import com.example.AnimalShelter.entity.UserEntity;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface UserRepo extends CrudRepository<UserEntity, Long> {
    UserEntity findByPhone(String phone);

}
