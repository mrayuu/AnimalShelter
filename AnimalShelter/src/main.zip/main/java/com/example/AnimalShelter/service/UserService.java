package com.example.AnimalShelter.service;

import com.example.AnimalShelter.entity.UserEntity;
import com.example.AnimalShelter.exception.UserAlreadyExistException;
import com.example.AnimalShelter.exception.UserNotFoundException;
import com.example.AnimalShelter.model.User;
import com.example.AnimalShelter.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    private UserRepo userRepo;

    public UserEntity registration(UserEntity user) throws UserAlreadyExistException {
        if (userRepo.findByPhone(user.getPhone()) != null) {
            throw new UserAlreadyExistException("Данный номер телефона уже используется другим пользователем");
        }
        return userRepo.save(user);
    }

    public User getOne (Long id) throws UserNotFoundException {
        UserEntity user = userRepo.findById(id).get();
        if (user == null) {
            throw new UserNotFoundException("Такого пользователя не существует");
        }
        return User.toModel(user);
    }

    public Long delete(Long id) {
        userRepo.deleteById(id);
        return id;
    }
}

