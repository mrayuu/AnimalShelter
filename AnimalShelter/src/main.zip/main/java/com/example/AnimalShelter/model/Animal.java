package com.example.AnimalShelter.model;

import com.example.AnimalShelter.entity.AnimalEntity;

public class Animal {

    private Long id;

    private String animal_name;

    private String breed;

    private String age;

    private String gender;

    private String color;

    private String size;

    private String vaccinations;

    private String diseases;

    private Boolean has_home;

    public static Animal toModel(AnimalEntity entity) {
        Animal model = new Animal();
        model.setId(entity.getId());
        model.setAnimal_name(entity.getAnimal_name());
        model.setBreed(entity.getBreed());
        model.setAge(entity.getAge());
        model.setGender(entity.getGender());
        model.setColor(entity.getColor());
        model.setSize(entity.getSize());
        model.setVaccinations(entity.getVaccinations());
        model.setDiseases(entity.getDiseases());
        model.setHas_home(entity.getHas_home());
        return model;
    }

    public Animal(){
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAnimal_name() {
        return animal_name;
    }

    public void setAnimal_name(String animal_name) {
        this.animal_name = animal_name;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getVaccinations() {
        return vaccinations;
    }

    public void setVaccinations(String vaccinations) {
        this.vaccinations = vaccinations;
    }

    public String getDiseases() {
        return diseases;
    }

    public void setDiseases(String diseases) {
        this.diseases = diseases;
    }

    public Boolean getHas_home() {
        return has_home;
    }

    public void setHas_home(Boolean has_home) {
        this.has_home = has_home;
    }
}
