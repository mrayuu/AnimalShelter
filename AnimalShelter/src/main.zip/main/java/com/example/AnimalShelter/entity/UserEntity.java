package com.example.AnimalShelter.entity;
import jakarta.persistence.*;
import lombok.Data;

import java.util.*;

@Entity
@Table( name = "user")
public class UserEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String first_name;
    private String last_name;
    private String phone;
    private String password;
    private Long credit_card;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "user")
    public List<AnimalEntity> animals;

    public UserEntity () {
     }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Long getCredit_card() {
        return credit_card;
    }

    public void setCredit_card(Long credit_card) {
        this.credit_card = credit_card;
    }


    public List<AnimalEntity>  getAnimals() {
        return animals;
    }
}
