package com.example.AnimalShelter;

import com.example.AnimalShelter.entity.AnimalEntity;
import com.example.AnimalShelter.repository.AnimalRepo;
import com.example.AnimalShelter.service.AnimalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Optional;

@Controller
@RequestMapping
public class AnimalController {

    @Autowired
    private AnimalService animalService;

    @Autowired
    private AnimalRepo animalRepo;

    @GetMapping("/animals")
    public String animals (Model model) {
        Iterable<AnimalEntity> animals = animalRepo.findAll();
        model.addAttribute("animals", animals);
        return "animals";
    }
    @GetMapping("/animals/add")
    public String animalsAdd (Model model) {
        return "animals-add";
    }

    @PostMapping("/animals/add")
    public  String animalPostAdd (@RequestParam String animal_name,@RequestParam String gender, @RequestParam String age, @RequestParam String breed, @RequestParam String color, @RequestParam String size, @RequestParam String vaccinations, @RequestParam String diseases, @RequestParam String description,  Model model) {
        AnimalEntity animal = new AnimalEntity(animal_name, gender, age, breed, color, size, vaccinations, diseases, description);
        animalRepo.save(animal);
        return "redirect:/animals";
    }

    @GetMapping("/animals/{id}")
    public String animalsDetails (@PathVariable(value = "id") long id, Model model) {
        if (!animalRepo.existsById(id)) {
            return "redirect:/animals";
        }

        Optional<AnimalEntity> animal = animalRepo.findById(id);
        ArrayList<AnimalEntity> res = new ArrayList<>();
        animal.ifPresent(res::add);
        model.addAttribute("animal", res);
        return "animals-details";
    }

    @GetMapping("/animals/{id}/edit")
    public String animalsEdit (@PathVariable(value = "id") long id, Model model) {
        if (!animalRepo.existsById(id)) {
            return "redirect:/animals";
        }

        Optional<AnimalEntity> animal = animalRepo.findById(id);
        ArrayList<AnimalEntity> res = new ArrayList<>();
        animal.ifPresent(res::add);
        model.addAttribute("animal", res);
        return "animals-edit";
    }

    @PostMapping("/animals/{id}/edit")
    public  String animalPostUpdate (@PathVariable(value = "id") long id, @RequestParam String animal_name,@RequestParam String gender, @RequestParam String age, @RequestParam String breed, @RequestParam String color, @RequestParam String size, @RequestParam String vaccinations, @RequestParam String diseases, @RequestParam String description,  Model model) {
        AnimalEntity animal = animalRepo.findById(id).orElseThrow();
        animal.setAnimal_name(animal_name);
        animal.setGender(gender);
        animal.setAge(age);
        animal.setBreed(breed);
        animal.setColor(color);
        animal.setSize(size);
        animal.setVaccinations(vaccinations);
        animal.setDiseases(diseases);
        animal.setDescription(description);
        animalRepo.save(animal);
        return "redirect:/animals";
    }

    @PostMapping("/animals/{id}/remove")
    public  String animalPostDelete (@PathVariable(value = "id") long id, Model model) {
        AnimalEntity animal = animalRepo.findById(id).orElseThrow();
        animalRepo.delete(animal);
        return "redirect:/animals";
    }


    @PostMapping
    public ResponseEntity createAnimal(@RequestBody AnimalEntity animal,
                                    @RequestParam Long userId) {
        try {
            return ResponseEntity.ok(animalService.createAnimal(animal,userId));

        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Произошла ошибка");
        }
    }

    @PutMapping
    public ResponseEntity addAnimal(@RequestParam Long id) {
        try {
            return ResponseEntity.ok(animalService.addAnimal(id));

        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Произошла ошибка");
        }
    }


}
