package com.example.AnimalShelter.service;


import com.example.AnimalShelter.entity.AnimalEntity;
import com.example.AnimalShelter.entity.UserEntity;
import com.example.AnimalShelter.model.Animal;
import com.example.AnimalShelter.repository.AnimalRepo;
import com.example.AnimalShelter.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AnimalService {
    @Autowired
    private AnimalRepo animalRepo;
    @Autowired
    private UserRepo userRepo;

    public Animal createAnimal(AnimalEntity animal, Long userId) {
        UserEntity user = userRepo.findById(userId).get();
        animal.setUser(user);
        return Animal.toModel(animalRepo.save(animal));


    }

    public Animal addAnimal(Long id) {
        AnimalEntity animal = animalRepo.findById(id).get();
        animal.setHas_home(!animal.getHas_home());
        return Animal.toModel(animalRepo.save(animal));
    }
}
