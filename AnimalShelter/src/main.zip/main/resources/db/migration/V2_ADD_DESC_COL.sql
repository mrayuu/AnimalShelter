ALTER TABLE animal ADD description VARCHAR(255);

UPDATE animal set description="value))";